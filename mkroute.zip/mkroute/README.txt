mkroute -f CN.txt -i <AdapterName or YourIPAddress>
效果：所有往中国区的流量都走 <AdapterName or YourIPAddress> 指定的网络